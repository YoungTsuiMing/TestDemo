package com.xiaoleilu.hutool.crypto.asymmetric;

/**
 * 密钥类型
 * 
 * @author Looly
 *
 */
public enum KeyType {
	PrivateKey, PublicKey;
}