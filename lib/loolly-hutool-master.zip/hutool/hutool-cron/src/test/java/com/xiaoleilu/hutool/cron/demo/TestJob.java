package com.xiaoleilu.hutool.cron.demo;

import com.xiaoleilu.hutool.lang.Console;

public class TestJob{
	public void doTest() {
		Console.log("Job running...");
	}
}
