package com.xiaoleilu.hutool.cron.pattern.parser;

/**
 * 秒值处理
 * @author Looly
 *
 */
public class SecondValueParser extends MinuteValueParser{
}
