package com.xiaoleilu.hutool.json.test.bean;

import java.util.Date;

public class UserB {
	private String name;
	private String b;
	private Date date;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getB() {
		return b;
	}
	public void setB(String a) {
		this.b = a;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
}
