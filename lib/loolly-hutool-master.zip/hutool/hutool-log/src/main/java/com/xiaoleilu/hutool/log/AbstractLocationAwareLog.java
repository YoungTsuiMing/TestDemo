package com.xiaoleilu.hutool.log;

/**
 * 抽象定位感知日志实现<br>
 * @author Looly
 *
 */
public abstract class AbstractLocationAwareLog extends AbstractLog implements LocationAwareLog{
	private static final long serialVersionUID = -5529674971846264145L;

}
