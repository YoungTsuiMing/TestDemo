git commit -am "$1"
