#!/bin/bash

#--------------------------------------
# Check dependency, thanks to t-io
#--------------------------------------

mvn versions:display-dependency-updates
