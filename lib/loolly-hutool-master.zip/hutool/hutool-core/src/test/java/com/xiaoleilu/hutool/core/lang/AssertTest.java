package com.xiaoleilu.hutool.core.lang;

import org.junit.Test;

public class AssertTest {
	
	@Test
	public void isNullTest(){
		String a = null;
		com.xiaoleilu.hutool.lang.Assert.isNull(a);
	}
	@Test
	public void notNullTest(){
		String a = null;
		com.xiaoleilu.hutool.lang.Assert.isNull(a);
	}
}
